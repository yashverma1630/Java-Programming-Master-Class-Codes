import java.util.*;
public class App {
    public static void main(String[] args){
        int j = 1;
        while(j<=5){
            System.out.println( j );
            j++;
        }
    }
}
