public class Dog {
    private String dogname;
    private String breed;

    public String getDogname() {
        return dogname;
    }

    public String getBreed() {
        return breed;
    }

    public void setDogname(String dogname) {
        this.dogname = dogname;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }
}
