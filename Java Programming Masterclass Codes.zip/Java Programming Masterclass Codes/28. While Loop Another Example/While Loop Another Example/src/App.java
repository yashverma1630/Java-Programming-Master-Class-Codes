import java.util.*;
public class App {
    public static void main(String[] args){
        int j = 1;
        while(true){
            if(j>5){
                break;
            }
            System.out.println( j );
            j++;
        }
    }
}
