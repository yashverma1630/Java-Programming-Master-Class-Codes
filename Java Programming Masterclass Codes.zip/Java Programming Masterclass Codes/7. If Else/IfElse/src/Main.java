public class Main {
    public static void main(String[] args) {
        int score = 1800;
        if (score>1800 && score<1800){
            System.out.print("code executed we are in if block");
        }

        else if (score>=1800){
            System.out.print("code is executed we are in else if block");
        }

        else {
            System.out.print("we are in else block");
        }
    }
}
