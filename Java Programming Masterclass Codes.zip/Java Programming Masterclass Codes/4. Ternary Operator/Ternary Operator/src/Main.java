public class Main {
    public static void main(String[] args) {
        String car="Volkswagen";
        boolean iscar=(car=="Volkswagen") ? true:false;
        if(iscar){
            System.out.println(iscar);
        }
        else{
            System.out.println(iscar);
        }

//        or we can do this ...

        // String s = (iscar)? "car is volkswagen":"it is a rikshaw";
        // System.out.print(s);
    }
}
