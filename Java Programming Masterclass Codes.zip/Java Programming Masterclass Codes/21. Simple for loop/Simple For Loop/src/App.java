import java.util.*;
public class App {
    public static void main(String[] args){
        for (int counter=0; counter<=5; counter++){
            System.out.println(counter);
        }
    }
}
